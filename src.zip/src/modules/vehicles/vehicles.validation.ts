import { z } from "zod";

const getSingleVehicleParamsSchema = z.object({
  id: z.string().uuid("Invalid vehicle id format"),
});

export const vehiclesValidation = {
  getSingleVehicleParamsSchema,
};